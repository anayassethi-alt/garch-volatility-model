"""
run_analysis.py
----------------
Applies the GARCH(1,1) model to real ETF return data and benchmarks it
against two simpler alternatives:
  1. Constant-variance (historical std dev) model
  2. Rolling-window historical volatility model

This comparison is the point: GARCH is only worth using if it actually
outperforms simpler approaches. This script tests that rather than assuming it.
"""

import numpy as np
import matplotlib.pyplot as plt
from garch import GARCH11

# ---------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------
daily_ret = np.load("daily_returns.npy", allow_pickle=True).item()

TICKERS = ["VTV", "QQQ", "VO", "VOE", "AGG", "VT"]  # representative cross-section:
                                                      # value, growth, core, bonds, world

# ---------------------------------------------------------------
# 2. Fit GARCH(1,1) for each ticker
# ---------------------------------------------------------------
results = {}
for ticker in TICKERS:
    r = daily_ret[ticker]
    model = GARCH11().fit(r)
    results[ticker] = model
    print(f"\n=== {ticker} ===")
    print(model.summary())

# ---------------------------------------------------------------
# 3. Model comparison: GARCH vs. constant variance vs. rolling window
#    Metric: out-of-sample log-likelihood on a held-out final 20% of data
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("MODEL COMPARISON (out-of-sample fit quality)")
print("=" * 60)

comparison = {}
for ticker in TICKERS:
    r = daily_ret[ticker]
    split = int(len(r) * 0.8)
    train, test = r[:split], r[split:]

    # GARCH: fit on train, evaluate conditional variance forecast on test
    model = GARCH11().fit(train)
    sigma2 = model.sigma2_[-1]
    prev_ret = train[-1]
    garch_ll = 0.0
    for t in test:
        sigma2 = model.omega_ + model.alpha_ * prev_ret ** 2 + model.beta_ * sigma2
        garch_ll += -0.5 * (np.log(2 * np.pi * sigma2) + t ** 2 / sigma2)
        prev_ret = t

    # Constant variance: use train variance, apply flat to all test points
    const_var = np.var(train)
    const_ll = np.sum(-0.5 * (np.log(2 * np.pi * const_var) + test ** 2 / const_var))

    # Rolling window (20-day trailing realized variance)
    window = 20
    full = np.concatenate([train[-window:], test])
    roll_ll = 0.0
    for i in range(len(test)):
        seg = full[i:i + window]
        v = np.var(seg) if np.var(seg) > 1e-10 else const_var
        roll_ll += -0.5 * (np.log(2 * np.pi * v) + test[i] ** 2 / v)

    comparison[ticker] = {"GARCH": garch_ll, "Constant Var": const_ll, "Rolling-20d": roll_ll}
    best = max(comparison[ticker], key=comparison[ticker].get)
    print(f"{ticker}: GARCH={garch_ll:.1f}  Constant={const_ll:.1f}  Rolling20d={roll_ll:.1f}  -> best: {best}")

# ---------------------------------------------------------------
# 4. Diagnostic plots
# ---------------------------------------------------------------
fig, axes = plt.subplots(3, 2, figsize=(13, 12))
axes = axes.flatten()

for i, ticker in enumerate(TICKERS):
    model = results[ticker]
    ann_vol = np.sqrt(model.sigma2_ * 252)
    axes[i].plot(ann_vol, linewidth=0.8, color="#16243D")
    axes[i].set_title(f"{ticker} — GARCH(1,1) Conditional Volatility (annualized)", fontsize=10)
    axes[i].set_xlabel("Trading day")
    axes[i].set_ylabel("Annualized vol")
    axes[i].grid(alpha=0.3)

plt.tight_layout()
plt.savefig("garch_volatility_plots.png", dpi=150)
print("\nSaved garch_volatility_plots.png")

# ---------------------------------------------------------------
# 5. Forecast comparison table
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("1-YEAR FORECAST (GARCH, 5000 simulated paths)")
print("=" * 60)
for ticker in TICKERS:
    fcst = results[ticker].forecast()
    print(f"{ticker}: median={np.median(fcst):+.1%}  "
          f"5th%={np.percentile(fcst,5):+.1%}  95th%={np.percentile(fcst,95):+.1%}")
