"""
garch.py
--------
A from-scratch implementation of the GARCH(1,1) volatility model, fit via
maximum likelihood estimation.

Why from scratch? The standard `arch` Python package was not available in
the environment this was built in. Rather than treat that as a blocker,
this implements the model directly from its mathematical definition, which
also makes the mechanics fully transparent and auditable line by line,
rather than hidden behind a library call.

Model:
    r_t = mu + eps_t
    eps_t = sigma_t * z_t,  z_t ~ N(0, 1)
    sigma_t^2 = omega + alpha * eps_(t-1)^2 + beta * sigma_(t-1)^2

Stationarity requires omega > 0, alpha >= 0, beta >= 0, alpha + beta < 1.
"""

import numpy as np
from scipy.optimize import minimize


class GARCH11:
    """Fits and forecasts a GARCH(1,1) conditional volatility model."""

    def __init__(self):
        self.omega_ = None
        self.alpha_ = None
        self.beta_ = None
        self.fitted_ = False
        self.sigma2_ = None
        self.returns_ = None
        self.loglik_ = None
        self.n_obs_ = None

    @staticmethod
    def _neg_log_likelihood(params, returns):
        omega, alpha, beta = params
        # Enforce stationarity and positivity constraints
        if omega <= 0 or alpha < 0 or beta < 0 or alpha + beta >= 1:
            return 1e10

        n = len(returns)
        sigma2 = np.empty(n)
        sigma2[0] = np.var(returns)  # initialize at unconditional variance
        for t in range(1, n):
            sigma2[t] = omega + alpha * returns[t - 1] ** 2 + beta * sigma2[t - 1]

        # Gaussian log-likelihood, dropping the constant term
        ll = -0.5 * np.sum(np.log(2 * np.pi * sigma2) + returns ** 2 / sigma2)
        return -ll

    def fit(self, returns, x0=None, maxiter=2000):
        """
        Fit GARCH(1,1) via maximum likelihood.

        Parameters
        ----------
        returns : array-like of daily returns (should be de-meaned or near-zero mean)
        x0 : optional initial guess [omega, alpha, beta]
        """
        returns = np.asarray(returns, dtype=float)
        if x0 is None:
            x0 = [np.var(returns) * 0.05, 0.08, 0.85]  # typical GARCH starting values

        result = minimize(
            self._neg_log_likelihood, x0, args=(returns,),
            method="Nelder-Mead",
            options={"maxiter": maxiter, "xatol": 1e-8, "fatol": 1e-8},
        )

        self.omega_, self.alpha_, self.beta_ = result.x
        self.returns_ = returns
        self.loglik_ = -result.fun
        self.n_obs_ = len(returns)
        self.converged_ = result.success

        # Reconstruct the fitted conditional variance series
        n = len(returns)
        sigma2 = np.empty(n)
        sigma2[0] = np.var(returns)
        for t in range(1, n):
            sigma2[t] = self.omega_ + self.alpha_ * returns[t - 1] ** 2 + self.beta_ * sigma2[t - 1]
        self.sigma2_ = sigma2
        self.fitted_ = True
        return self

    @property
    def persistence(self):
        """alpha + beta: how slowly volatility shocks decay. Closer to 1 = more persistent."""
        return self.alpha_ + self.beta_

    @property
    def long_run_variance(self):
        """Unconditional (long-run) variance implied by the fitted model."""
        p = self.persistence
        if p >= 1:
            return np.var(self.returns_)  # fallback if non-stationary fit
        return self.omega_ / (1 - p)

    @property
    def aic(self):
        """Akaike Information Criterion (lower = better fit, penalizes complexity)."""
        k = 3  # omega, alpha, beta
        return 2 * k - 2 * self.loglik_

    def forecast(self, horizon_days=252, n_sims=5000, seed=42):
        """
        Simulate forward paths using the fitted GARCH(1,1) process.
        Volatility clusters (unlike i.i.d. bootstrap resampling) because each
        simulated day's variance depends on the prior simulated shock and variance.
        """
        if not self.fitted_:
            raise RuntimeError("Call .fit() before .forecast()")

        rng = np.random.default_rng(seed)
        last_sigma2 = self.sigma2_[-1]
        last_ret = self.returns_[-1]

        cum_returns = np.empty(n_sims)
        for i in range(n_sims):
            sigma2 = last_sigma2
            prev_ret = last_ret
            cum = 1.0
            for t in range(horizon_days):
                sigma2 = self.omega_ + self.alpha_ * prev_ret ** 2 + self.beta_ * sigma2
                shock = rng.standard_normal() * np.sqrt(sigma2)
                cum *= (1 + shock)
                prev_ret = shock
            cum_returns[i] = cum - 1
        return cum_returns

    def summary(self):
        if not self.fitted_:
            return "Model not fitted."
        ann_vol = np.sqrt(self.long_run_variance * 252)
        return (
            f"GARCH(1,1) fit (n={self.n_obs_} obs)\n"
            f"  omega       = {self.omega_:.6f}\n"
            f"  alpha       = {self.alpha_:.4f}\n"
            f"  beta        = {self.beta_:.4f}\n"
            f"  persistence = {self.persistence:.4f}\n"
            f"  long-run ann. vol = {ann_vol:.2%}\n"
            f"  log-likelihood    = {self.loglik_:.2f}\n"
            f"  AIC               = {self.aic:.2f}\n"
            f"  converged         = {self.converged_}"
        )
